/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package constants;

/**
 *
 * @author Samsung
 */
public interface Constants {
    public int SCREEN_HEIGHT = 600;
    public int SCREEN_WIDTH =   800;
    
}
